
var header_height = 90;
var min_header_height_scroll = 57;
var header_one_scroll_resize = false;
var min_header_height_sticky = 60;
var scroll_amount_for_sticky = 85;
var min_header_height_fixed_hidden = 45;
var header_bottom_border_weight = 1;
var scroll_amount_for_fixed_hiding = 200;
var menu_item_margin = 0;
var large_menu_item_border = 0;
var element_appear_amount = -150;
var paspartu_width_init = 0.02;
var directionNavArrows = 'arrow_carrot-';
var directionNavArrowsTestimonials = 'fa fa-angle-';
var enable_navigation_on_full_screen_section = false;
var add_for_admin_bar = 0;
	header_height = 90;





var logo_height = 130; // pitch logo height
var logo_width = 280; // pitch logo width
	    logo_width = 272;
    logo_height = 67;

	
	header_top_height = 0;
var loading_text;
loading_text = 'Loading new posts...';
var finished_text;
finished_text = 'No more posts';

var piechartcolor;
piechartcolor	= "#279eff";

	piechartcolor = "#59595b";





var no_ajax_pages = [];
var qode_root = 'http://www.adrcenter.com/';
var theme_root = 'http://www.adrcenter.com/wp-content/themes/pitchwp/';
var header_style_admin = "";
if(typeof no_ajax_obj !== 'undefined') {
no_ajax_pages = no_ajax_obj.no_ajax_pages;
}

var login_page = 0;
var logoutString = "Logout";
